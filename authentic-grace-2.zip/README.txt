A Pen created at CodePen.io. You can find this one at https://codepen.io/pbfine-the-typescripter/pen/vbPGLJ.

 A responsive landing page for a women's online clothing store, created with HTML, CSS and Bootstrap.